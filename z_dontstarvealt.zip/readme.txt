Don't Starve ballons made from modified in-game assets

This version uses Times New Roman for better readability


~Digibillcipher/Player_056