Don't Starve ballons made from modified in-game assets

You'll want to install the included font which is what Don't Starve uses, but modified to be more readable.


~Digibillcipher/Player_056