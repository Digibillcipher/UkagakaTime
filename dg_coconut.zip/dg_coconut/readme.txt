Hydrate Coconut Shell made entirely on an iPhone6s

Used a zip version of the hydrate 1.0.1 template

Made for 8/20 Hydrate Shell Jam 2025
By Digi_056 v1.0.0