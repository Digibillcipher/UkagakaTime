Don't Starve ballons made from modified in-game assets

You'll want to install the included font which is what Don't Starve uses, but modified to be more readable.


~Digibillcipher/Player_056

--------Sample balloon info
This simple balloon is meant to be studied by enterprising balloon makers. You can find the page with more details on exactly which steps to go through at http://www.ashido.com/ukagaka/
For those reusing or repurposing some of these files, fill out this readme with any information you'd like a potential balloon user to know, like any updates you've made, or what site you can be found out, or whatever.
--------Version History
Ver 1.1 - Removed the pna files and added a line in descript.txt so they aren't necessary.
Ver 1.0 - Balloon Release